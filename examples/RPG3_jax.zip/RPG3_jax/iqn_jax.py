import jax
import jax.numpy as jnp
import jax.random
from flax import linen as nn
import heapq
from collections import deque
import random
import numpy as np
import optax
import time


class ReplayBuffer:
    """
    ReplayBuffer for Reinforcement Learning
    """

    def __init__(self, capacity):
        self.buffer = deque(maxlen=capacity)

    def add(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        sampled_experiences = random.sample(self.buffer, batch_size)

        # Convert tensors to NumPy arrays and ensure consistent shapes
        states = np.array([exp[0].numpy() for exp in sampled_experiences])
        actions = np.array([exp[1] for exp in sampled_experiences])
        rewards = np.array([exp[2] for exp in sampled_experiences])
        next_states = np.array([exp[3].numpy() for exp in sampled_experiences])
        dones = np.array([exp[4] for exp in sampled_experiences])

        return states, actions, rewards, next_states, dones

    def __len__(self):
        return len(self.buffer)


class PrioritizedReplayBuffer:
    def __init__(self, capacity, default_priority=1.0):
        self.buffer = []
        self.priority_queue = []  # Min-heap for efficient priority management
        self.capacity = capacity
        self.default_priority = default_priority
        self.size = 0
        self.total_priority = 0  # Initialize total_priority

    def add(self, state, action, reward, next_state, done):
        priority = self.default_priority
        experience = (state, action, reward, next_state, done, priority)
        if self.size < self.capacity:
            heapq.heappush(self.priority_queue, (priority, self.size))
            self.buffer.append(experience)
            self.size += 1
        else:
            _, min_priority_index = heapq.heappop(self.priority_queue)
            self.total_priority -= self.buffer[min_priority_index][5]
            self.buffer[min_priority_index] = experience
            heapq.heappush(self.priority_queue, (priority, min_priority_index))
        self.total_priority += priority  # Update total_priority when adding

    def sample(self, batch_size, alpha=0.6, beta=0.4):
        priorities = [exp[5] for exp in self.buffer]
        scaled_priorities = np.array(priorities) ** alpha
        probabilities = scaled_priorities / np.sum(scaled_priorities)

        sampled_indices = np.random.choice(self.size, batch_size, p=probabilities)
        sampled_experiences = [self.buffer[idx] for idx in sampled_indices]

        # Calculate importance-sampling weights
        weights = [
            (1.0 / (self.size * probabilities[idx])) ** beta for idx in sampled_indices
        ]
        max_weight = max(weights)
        normalized_weights = [w / max_weight for w in weights]

        return sampled_experiences, normalized_weights, sampled_indices

    def update_priorities(self, indices, priorities):
        for i, priority in zip(indices, priorities):
            # Update the experience with the new priority
            self.buffer[i] = self.buffer[i][:5] + (priority,)

    def __len__(self):
        return len(self.buffer)


class NoisyDense(nn.Module):
    """
    NoisyDense: A Custom Noisy Dense Layer in JAX

    Implements a noisy dense layer using Flax's Linen API. Introduces noise to the weights and biases,
    useful for reinforcement learning algorithms that benefit from exploration.

    Attributes:
    - features: The number of output features (neurons) of the layer.
    - std_init: The standard deviation used for initializing the noise parameters.
    """

    features: int
    std_init: float = 0.4

    @nn.compact
    def __call__(self, x, rng_key):
        input_features = x.shape[-1]

        # Mean weights and biases
        W_mu = self.param(
            "W_mu", nn.initializers.xavier_uniform(), (input_features, self.features)
        )
        b_mu = self.param("b_mu", nn.initializers.zeros, (self.features,))

        # Splitting the RNG key
        key1, key2 = jax.random.split(rng_key)

        # Generating noise for weights and biases
        W_noise = (
            jax.random.normal(key1, (input_features, self.features), dtype=x.dtype)
            * self.std_init
        )
        b_noise = (
            jax.random.normal(key2, (self.features,), dtype=x.dtype) * self.std_init
        )

        # Combine mean and noise
        W = W_mu + W_noise
        b = b_mu + b_noise

        return jnp.dot(x, W) + b


class QNetwork(nn.Module):
    number_of_actions: int
    num_quantiles: int
    embedding_dim: int

    def quantile_embedding(self, num_quantiles, rng_key):
        quantiles = jax.random.uniform(rng_key, shape=(num_quantiles,))
        i = jnp.arange(self.embedding_dim, dtype=jnp.float32).reshape(1, -1)
        cosines = jnp.cos(jnp.pi * quantiles.reshape(-1, 1) * i)
        return cosines

    @nn.compact
    def __call__(self, x, rng_key=None, noisy=False):
        x = nn.Dense(512)(x)
        x = nn.relu(x)
        if noisy:
            _, noisy_rng_key = jax.random.split(rng_key)
            x = NoisyDense(features=512, std_init=0.1)(x, noisy_rng_key)
        else:
            x = nn.Dense(512)(x)
        x = nn.relu(x)
        x = nn.Dense(256)(x)
        x = nn.relu(x)

        quantile_embeddings = self.quantile_embedding(self.num_quantiles, rng_key)
        x = x.reshape(-1, 1, x.shape[-1])
        x = jnp.repeat(x, self.num_quantiles, axis=1)
        x = x * quantile_embeddings

        value_stream = nn.Dense(1)(x)
        advantage_stream = nn.Dense(self.number_of_actions)(x)
        q_values = (
            value_stream
            + advantage_stream
            - jnp.mean(advantage_stream, axis=2, keepdims=True)
        )

        return q_values.reshape(-1, self.num_quantiles, self.number_of_actions)


class doubleDQN:
    def __init__(
        self,
        input_size=1134,
        number_of_actions=4,
        lr=0.001,
        gamma=0.99,
        per=False,
        alpha=0.6,
        beta=0.4,
        beta_increment=0.0006,
        capacity=5000,
        num_quantiles=50,
        embedding_dim=64,
    ):
        self.input_size = input_size
        self.number_of_actions = number_of_actions
        self.lr = lr
        self.per = per
        self.gamma = gamma
        self.alpha = alpha
        self.beta = beta
        self.beta_increment = beta_increment
        self.capacity = capacity
        self.num_quantiles = num_quantiles
        self.embedding_dim = embedding_dim

        self.local_model = QNetwork(
            number_of_actions=number_of_actions,
            num_quantiles=num_quantiles,
            embedding_dim=embedding_dim,
        )
        self.target_model = QNetwork(
            number_of_actions=number_of_actions,
            num_quantiles=num_quantiles,
            embedding_dim=embedding_dim,
        )

        self.rng_key = jax.random.PRNGKey(0)

        if per:
            self.replay_buffer = PrioritizedReplayBuffer(capacity=capacity)
        else:
            self.replay_buffer = ReplayBuffer(capacity=capacity)

        dummy_input = jnp.zeros((1, input_size))
        self.local_model_params = self.local_model.init(
            jax.random.PRNGKey(0), dummy_input, self.rng_key
        )["params"]
        self.target_model_params = self.target_model.init(
            jax.random.PRNGKey(1), dummy_input, self.rng_key
        )["params"]

        self.optimizer = optax.adam(lr)
        self.optimizer_state = self.optimizer.init(self.local_model_params)

    def take_action(self, state, epsilon, rng):
        """
        Selects an action based on the current state, using an epsilon-greedy strategy.

        This method decides between exploration and exploitation using the epsilon value.
        With probability epsilon, it chooses a random action (exploration),
        and with probability 1 - epsilon, it chooses the best action based on the model's predictions (exploitation).

        Concern:
        - The method currently resets the RNG key using a new seed derived from the current time in milliseconds.
        This approach might not be ideal as it can lead to predictable sequences in the long run and does not
        utilize JAX's PRNG system effectively.

        Parameters:
        - state: The current state of the environment.
        - epsilon: The probability of choosing a random action.
        - rng: The JAX random number generator key.

        Things to Check:
        - Ensure that the RNG key is split or advanced correctly instead of being reseeded each time.
        In JAX, you typically use `jax.random.split` to get a new subkey.
        - Validate that the state is correctly reshaped and can be processed by the model during exploitation.
        - Confirm that the action space defined by `number_of_actions` aligns with the environment's action space.
        - Check that the `jax.random.uniform` and `jax.random.randint` functions are used correctly to generate random numbers and actions.

        Potential Improvements:
        - Modify the RNG handling to use `jax.random.split` for generating new keys.
        This will maintain the stochasticity without the need to reset the seed each time.
        - If the state requires specific preprocessing before being fed into the model,
        ensure that it's handled appropriately within this method or prior to calling it.
        - Consider parameterizing the number of actions if it varies across different environments or parts of your application.

        Returns:
        - The selected action, either random or the best according to the model.
        """

        # Split the RNG key
        seed = int(
            time.time() * 1000
        )  # need to figure out the jax random number generator key
        rng = jax.random.PRNGKey(seed)
        rng, rng_key_action = jax.random.split(rng)

        # Reshape state for model input
        state = state.reshape(-1, self.input_size)

        # Generate a random number for epsilon-greedy decision
        random_number = jax.random.uniform(rng_key_action, minval=0.0, maxval=1.0)

        if random_number < epsilon:
            # Exploration: choose a random action
            seed = int(time.time() * 1000)
            rng_key_action = jax.random.PRNGKey(seed)
            action = jax.random.randint(
                rng_key_action, shape=(), minval=0, maxval=self.number_of_actions
            )
        else:
            # Exploitation: choose the best action based on model prediction
            # Compute the mean of the predicted quantiles for each action
            seed = int(time.time() * 1000)
            rng_key = jax.random.PRNGKey(seed)
            predicted_quantiles = self.local_model.apply(
                {"params": self.local_model_params}, jnp.array([state]), rng_key
            )
            mean_q_values = jnp.mean(predicted_quantiles, axis=1)  # Mean over quantiles
            action = jnp.argmax(mean_q_values, axis=1)[0]

        return int(action)

    def compute_td_errors(self, params, states, actions, rewards, next_states, dones):
        q_values = self.local_model.apply({"params": params}, states)
        next_q_values = self.target_model.apply({"params": params}, next_states)
        max_next_q_values = jnp.max(next_q_values, axis=1)
        target_q_values = rewards + (self.gamma * max_next_q_values * (1 - dones))
        actions_one_hot = jax.nn.one_hot(actions, self.number_of_actions)
        predicted_q_values = jnp.sum(q_values * actions_one_hot, axis=1)
        return jnp.abs(predicted_q_values - target_q_values)

    def train_step(self, batch_size, soft_update=True):
        # Increment beta if using PER
        if self.per:
            self.beta = min(self.beta + self.beta_increment, 1)

        # Sample a batch from the replay buffer
        if self.per:
            sampled_batch, weights, indices = self.replay_buffer.sample(
                batch_size, self.alpha, self.beta
            )
            states, actions, rewards, next_states, dones, _ = map(
                np.array, zip(*sampled_batch)
            )
            weights = jnp.array(weights)
        else:
            states, actions, rewards, next_states, dones = self.replay_buffer.sample(
                batch_size
            )

        # Prepare inputs for the loss function
        inputs = {
            "states": states,
            "actions": actions,
            "rewards": rewards,
            "next_states": next_states,
            "dones": dones,
        }
        if self.per:
            inputs["weights"] = weights

        # Define the loss function
        def loss_fn(params, inputs):
            states, actions, rewards, next_states, dones = (
                inputs["states"],
                inputs["actions"],
                inputs["rewards"],
                inputs["next_states"],
                inputs["dones"],
            )

            # Compute predicted quantiles from the local model for current states
            predicted_quantiles = self.local_model.apply(
                {"params": params}, states, self.rng_key, noisy=True
            )

            # Compute target quantiles
            # This typically involves using the target model to predict future rewards and calculating the Bellman target
            next_state_quantiles = self.target_model.apply(
                {"params": self.target_model_params},
                next_states,
                self.rng_key,
                noisy=False,
            )
            max_next_state_quantiles = jnp.max(
                next_state_quantiles, axis=2
            )  # Max over action dimension
            target_quantiles = (
                rewards[:, None]
                + self.gamma * (1 - dones[:, None]) * max_next_state_quantiles
            )

            # Calculate the quantile regression loss
            td_errors = target_quantiles[:, :, None] - predicted_quantiles[:, None, :]
            huber_loss = optax.huber_loss(td_errors, delta=1.0)
            quantile_loss = jnp.abs(
                (
                    jnp.arange(1, self.local_model.num_quantiles + 1, dtype=jnp.float32)
                    / self.local_model.num_quantiles
                    - (td_errors < 0).astype(jnp.float32)
                )
                * huber_loss
            )
            loss = jnp.mean(
                quantile_loss, axis=(1, 2)
            )  # Mean over quantile and action dimensions

            # If using PER, adjust loss with importance sampling weights
            if self.per:
                weights = inputs["weights"]
                loss = jnp.mean(loss * weights)

            return loss

        # Compute gradients and update parameters
        grad_fn = jax.value_and_grad(loss_fn)
        loss, gradients = grad_fn(self.local_model_params, inputs)
        updates, self.optimizer_state = self.optimizer.update(
            gradients, self.optimizer_state
        )
        self.local_model_params = optax.apply_updates(self.local_model_params, updates)

        # Update the target network
        if soft_update:
            tau = 0.01
            self.target_model_params = jax.tree_map(
                lambda t, l: tau * l + (1 - tau) * t,
                self.target_model_params,
                self.local_model_params,
            )

        # Update priorities if using PER
        if self.per:
            td_errors = self.compute_td_errors(
                self.local_model_params, states, actions, rewards, next_states, dones
            )
            new_priorities = np.abs(td_errors) + 1e-6
            self.replay_buffer.update_priorities(indices, new_priorities.tolist())

        return loss

    def hard_update(self):
        """
        Perform a hard update on the target model parameters.

        This function directly copies the parameters from the local model to the
        target model. Unlike a soft update, which gradually blends the parameters
        of the local and target models, a hard update sets the target model
        parameters to be exactly equal to the local model parameters. This is
        typically done less frequently than soft updates and can be used to
        periodically reset the target model with the latest local model parameters.

        Usage:
            This function should be called at specific intervals (e.g., every 100
            epochs) during the training process, depending on the specific needs
            and dynamics of the training regimen.

        Note:
            Frequent hard updates can lead to more volatile training dynamics,
            whereas infrequent updates might cause the target model to lag too far
            behind the local model. The frequency of hard updates should be chosen
            carefully based on empirical results and the specific characteristics
            of the model and training data.
        """
        self.target_model_params = jax.tree_map(
            lambda l: l,
            self.local_model_params,
        )
